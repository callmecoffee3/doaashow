
import React from 'react';
import type { Product } from './FeaturedPrompts'; // Import type

interface ProductCardProps {
  product: Product;
  onSelectPrompt: (promptText: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelectPrompt }) => {
  return (
    <div 
      className="bg-slate-700 rounded-lg shadow-lg p-4 flex flex-col hover:shadow-xl transition-all duration-300 ease-in-out transform hover:-translate-y-1"
      role="article"
      aria-labelledby={`product-title-${product.id}`}
    >
      <img 
        src={product.sampleImageUrl} 
        alt={`Sample image for ${product.title}`}
        className="w-full h-40 object-cover rounded-md mb-4 image-pixelated shadow-md"
      />
      {/* Ensure pixelated rendering for sample images */}
      <style>{`
        .image-pixelated {
          image-rendering: pixelated; /* Standard */
          image-rendering: -moz-crisp-edges; /* Firefox */
          image-rendering: crisp-edges; /* Chrome, Safari, Edge */
        }
      `}</style>
      <h3 id={`product-title-${product.id}`} className="text-xl font-semibold text-text-primary mb-2">{product.title}</h3>
      <p className="text-sm text-text-secondary flex-grow mb-4">{product.description}</p>
      <button
        onClick={() => onSelectPrompt(product.promptText)}
        className="mt-auto w-full px-4 py-2 bg-brand-primary hover:bg-brand-secondary text-white font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-700 focus:ring-brand-primary transition-colors duration-200"
        aria-label={`Use prompt for ${product.title}`}
      >
        Use This Idea
      </button>
    </div>
  );
};
