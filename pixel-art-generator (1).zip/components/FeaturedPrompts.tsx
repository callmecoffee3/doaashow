
import React from 'react';
import { ProductCard } from './ProductCard';

export interface Product {
  id: string;
  title: string;
  description: string;
  promptText: string;
  sampleImageUrl: string;
}

interface FeaturedPromptsProps {
  products: Product[];
  onSelectPrompt: (promptText: string) => void;
}

const LightbulbIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={className || "w-6 h-6"}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.355a12.06 12.06 0 00-4.5 0M12 6.75A2.25 2.25 0 009.75 9V11.25A2.25 2.25 0 0012 13.5h.008c1.034 0 1.903-.832 1.992-1.862a2.25 2.25 0 00-1.345-2.569V6.75A2.25 2.25 0 0012 6.75z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3c.828 0 1.5.672 1.5 1.5S12.828 6 12 6s-1.5-.672-1.5-1.5S11.172 3 12 3zM12 18c.828 0 1.5.672 1.5 1.5S12.828 21 12 21s-1.5-.672-1.5-1.5S11.172 18 12 18zM12 9a3 3 0 100-6 3 3 0 000 6z" />
  </svg>
);


export const FeaturedPrompts: React.FC<FeaturedPromptsProps> = ({ products, onSelectPrompt }) => {
  if (!products || products.length === 0) {
    return null;
  }

  return (
    <section className="w-full max-w-4xl mx-auto mt-16 mb-8 px-4" aria-labelledby="featured-ideas-title">
      <h2 id="featured-ideas-title" className="text-3xl font-bold text-text-primary text-center mb-8 flex items-center justify-center space-x-2">
        <LightbulbIcon className="w-8 h-8 text-yellow-400" />
        <span>Featured Ideas</span>
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-6">
        {products.map((product) => (
          <ProductCard 
            key={product.id} 
            product={product} 
            onSelectPrompt={onSelectPrompt} 
          />
        ))}
      </div>
    </section>
  );
};
