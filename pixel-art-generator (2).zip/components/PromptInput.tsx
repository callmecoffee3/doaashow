
import React from 'react';

interface PromptInputProps {
  value: string;
  onChange: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
  onEnterPress: () => void;
  disabled: boolean;
}

const PencilIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={className || "w-5 h-5"}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
  </svg>
);


export const PromptInput: React.FC<PromptInputProps> = ({ value, onChange, onEnterPress, disabled }) => {
  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      onEnterPress();
    }
  };
  
  return (
    <div className="relative">
      <label htmlFor="prompt-input" className="block text-sm font-medium text-text-secondary mb-1">
        Enter your pixel art idea
      </label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <PencilIcon className="h-5 w-5 text-slate-400" />
        </div>
        <textarea
          id="prompt-input"
          value={value}
          onChange={onChange}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          placeholder="e.g., a knight fighting a dragon, a futuristic cityscape..."
          rows={3}
          className="w-full p-3 pl-10 pr-10 bg-slate-700 text-text-primary border border-slate-600 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-brand-primary transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed resize-none shadow-sm"
          aria-label="Pixel art prompt"
        />
        <div className="absolute bottom-2 right-2 text-xs text-slate-500">
          Enter to submit
        </div>
      </div>
    </div>
  );
};
