
import React, { useState, useCallback } from 'react';
import { generatePixelArt } from './services/geminiService';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { ImageDisplay } from './components/ImageDisplay';
import { PromptInput } from './components/PromptInput';
import { GenerateButton } from './components/GenerateButton';
import { FeaturedPrompts, Product } from './components/FeaturedPrompts';

// Simple GitHub Octocat Icon for header
const GithubIcon: React.FC = () => (
  <svg height="32" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="32" fill="currentColor">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.19.01-.82.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21-.15.46-.55.38A8.013 8.013 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path>
  </svg>
);

const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={className || "w-8 h-8"}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12L17 14.25l-1.25-2.25L13.5 11l2.25-1.25L17 7.5l1.25 2.25L20.5 11l-2.25 1.25z" />
  </svg>
);

const CpuChipIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={className || "w-5 h-5"}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M8.25 21v-1.5M15.75 3v1.5m0 15v1.5M12 4.5v-1.5m0 15v1.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 7.5h6V12h-6V7.5zM12.75 12h6v4.5h-6V12zM5.25 7.5h6V12h-6V7.5zM5.25 12h6v4.5h-6V12z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 7.5h16.5v9H3.75v-9z" />
  </svg>
);


const sampleProductsData: Product[] = [
  {
    id: '1',
    title: 'Mystic Forest',
    description: 'A serene, glowing forest with ancient trees and sparkling sprites.',
    promptText: 'A serene, glowing mystical forest with ancient, gnarled trees and tiny, sparkling light sprites, 8-bit style.',
    sampleImageUrl: 'https://via.placeholder.com/200x150/3B5998/FFFFFF?text=Mystic+Forest',
  },
  {
    id: '2',
    title: 'Cyberpunk Alley',
    description: 'A neon-lit alleyway in a futuristic city, rain-slicked streets.',
    promptText: 'A dark, neon-lit cyberpunk alleyway with rain-slicked streets and towering skyscrapers in the background, 16-bit pixel art.',
    sampleImageUrl: 'https://via.placeholder.com/200x150/4f46e5/FFFFFF?text=Cyberpunk+Alley',
  },
  {
    id: '3',
    title: 'Heroic Knight',
    description: 'A brave knight in shining armor, holding a sword and shield.',
    promptText: 'A heroic knight in detailed shining armor, wielding a sword and shield, standing on a castle battlement, classic pixel art.',
    sampleImageUrl: 'https://via.placeholder.com/200x150/ef4444/FFFFFF?text=Heroic+Knight',
  },
  {
    id: '4',
    title: 'Cozy Cafe Scene',
    description: 'A warm, inviting cafe interior with a cat sleeping on a windowsill.',
    promptText: 'A cozy, warm cafe interior, soft lighting, steam rising from a coffee cup, a cat sleeping on the windowsill, detailed pixel art.',
    sampleImageUrl: 'https://via.placeholder.com/200x150/f97316/FFFFFF?text=Cozy+Cafe',
  },
];


const App: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGeneratePixelArt = useCallback(async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt to generate pixel art.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedImageUrl(null);

    try {
      const result = await generatePixelArt({ prompt });
      if ('imageUrl' in result) {
        setGeneratedImageUrl(result.imageUrl);
      } else {
        setError(result.error);
      }
    } catch (e) {
      console.error("Unhandled error in generation process:", e);
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [prompt]);

  const handleProductSelect = useCallback((selectedPrompt: string) => {
    setPrompt(selectedPrompt);
    // Optionally, scroll to the top or to the prompt input
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-start p-4 bg-gradient-to-br from-bg-dark via-slate-800 to-bg-dark text-text-primary">
      <header className="w-full max-w-2xl mx-auto mt-8 mb-8 text-center">
        <div className="flex items-center justify-center space-x-3 mb-4">
          <SparklesIcon className="w-10 h-10 text-pink-400" />
          <h1 className="text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-pink-500">
            Pixel Art Generator
          </h1>
           <a href="https://github.com/your-repo" target="_blank" rel="noopener noreferrer" aria-label="View source on GitHub" className="text-text-secondary hover:text-text-primary transition-colors">
            <GithubIcon />
          </a>
        </div>
        <p className="text-text-secondary text-lg">
          Enter a prompt and let AI create unique pixel art for you using Gemini Imagen.
        </p>
      </header>

      <main className="w-full max-w-xl bg-bg-light p-6 sm:p-8 rounded-xl shadow-2xl space-y-6">
        <PromptInput
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onEnterPress={handleGeneratePixelArt}
          disabled={isLoading}
        />
        
        <GenerateButton
          onClick={handleGeneratePixelArt}
          isLoading={isLoading}
        />

        {error && <ErrorMessage message={error} />}
        
        <ImageDisplay 
          imageUrl={generatedImageUrl}
          isLoading={isLoading}
          prompt={prompt}
        />
      </main>

      <FeaturedPrompts 
        products={sampleProductsData} 
        onSelectPrompt={handleProductSelect} 
      />

      <footer className="w-full max-w-2xl mx-auto mt-12 mb-8 text-center text-text-secondary text-sm">
        <p className="flex items-center justify-center">
            <CpuChipIcon className="w-5 h-5 mr-2 text-slate-500" /> 
            &copy; {new Date().getFullYear()} Pixel Art Generator. Powered by Gemini.
        </p>
        <p className="mt-1">Ensure your API_KEY environment variable is configured.</p>
      </footer>
    </div>
  );
};

export default App;
