
import React from 'react';
import LuIconBase from './LuIconBase';

const LuPlay: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <LuIconBase {...props}>
    <polygon points="5 3 19 12 5 21 5 3" />
  </LuIconBase>
);

export default LuPlay;
