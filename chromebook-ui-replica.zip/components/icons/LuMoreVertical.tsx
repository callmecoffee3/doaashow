import React from 'react';
import LuIconBase from './LuIconBase';

const LuMoreVertical: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <LuIconBase {...props}>
    <circle cx="12" cy="12" r="1" />
    <circle cx="12" cy="5" r="1" />
    <circle cx="12" cy="19" r="1" />
  </LuIconBase>
);

export default LuMoreVertical;