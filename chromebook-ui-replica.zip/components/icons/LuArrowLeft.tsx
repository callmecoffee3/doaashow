import React from 'react';
import LuIconBase from './LuIconBase';

const LuArrowLeft: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <LuIconBase {...props}>
    <line x1="19" y1="12" x2="5" y2="12" />
    <polyline points="12 19 5 12 12 5" />
  </LuIconBase>
);

export default LuArrowLeft;