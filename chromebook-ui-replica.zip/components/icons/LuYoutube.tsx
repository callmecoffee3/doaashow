
import React from 'react';
// Using a simplified representation for YouTube
const LuYoutube: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M24.918 4.087A2.906 2.906 0 0022.855 2.4C20.871 2 14 2 14 2s-6.871 0-8.855.4C3.082 2.621 1.501 4.087 1.282 6.064A30.158 30.158 0 001 9.997c0 1.612.101 2.83.282 3.933.22.977.8 2.443 2.863 2.658 1.984.4 8.855.4 8.855.4s6.871 0 8.855-.4c1.964-.215 2.644-1.681 2.863-2.658.181-1.104.282-2.32.282-3.933s-.101-2.83-.282-3.933zm-14.95 9.07V6.841l6.822 3.129-6.822 3.187z" clipRule="evenodd" className="text-red-600"/>
  </svg>
);

export default LuYoutube;
