import React from 'react';
import ChromeLogoIcon from './ChromeLogoIcon';
// import RedTechLogo from './RedTechLogo'; // No longer needed here
import LuArrowLeft from './icons/LuArrowLeft';
import LuArrowRight from './icons/LuArrowRight';
import LuRefreshCw from './icons/LuRefreshCw';
import LuLock from './icons/LuLock';
import LuStar from './icons/LuStar';
import LuSettings2 from './icons/LuSettings2'; // Re-using for an extension icon
import LuShield from './icons/LuShield';
import LuPuzzle from './icons/LuPuzzle';
import LuUserCircle2 from './icons/LuUserCircle2';
import LuMoreVertical from './icons/LuMoreVertical';

const BrowserWindow: React.FC = () => {
  return (
    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[85vw] h-[80vh] max-w-[1200px] max-h-[800px] bg-white rounded-lg shadow-2xl flex flex-col overflow-hidden border border-gray-300">
      {/* Top Bar: Tabs + Window Controls */}
      <div className="bg-neutral-200 h-10 flex items-center px-1 shrink-0 border-b border-gray-300">
        {/* Active Tab */}
        <div className="bg-white px-4 py-1 h-full flex items-center rounded-t-md shadow-sm border-r border-l border-t border-gray-300 relative -mb-px mr-1 z-10">
          <ChromeLogoIcon className="w-4 h-4 mr-2 text-gray-600 shrink-0" />
          <span className="text-xs text-neutral-800 truncate">New Tab</span>
          <button aria-label="Close tab" className="ml-3 text-xs text-gray-400 hover:text-gray-700 shrink-0">&times;</button>
        </div>
        {/* Placeholder for more tabs or new tab button */}
        {/* Window Controls */}
        <div className="ml-auto flex space-x-2 pr-2">
          <div className="w-3 h-3 bg-neutral-400 rounded-full hover:bg-neutral-500 cursor-pointer" aria-label="Minimize" role="button"></div>
          <div className="w-3 h-3 bg-neutral-400 rounded-full hover:bg-neutral-500 cursor-pointer" aria-label="Maximize" role="button"></div>
          <div className="w-3 h-3 bg-red-500 rounded-full hover:bg-red-600 cursor-pointer" aria-label="Close" role="button"></div>
        </div>
      </div>

      {/* Toolbar: Nav, Address, Extensions, Menu */}
      <div className="bg-neutral-100 h-11 flex items-center px-2 space-x-2 shrink-0 border-b border-gray-300">
        {/* Nav Buttons */}
        <div className="flex items-center space-x-0.5">
          <button className="p-1.5 rounded hover:bg-black/10" aria-label="Back"><LuArrowLeft size={18} className="text-neutral-600" /></button>
          <button className="p-1.5 rounded hover:bg-black/10" aria-label="Forward"><LuArrowRight size={18} className="text-neutral-600" /></button>
          <button className="p-1.5 rounded hover:bg-black/10" aria-label="Reload"><LuRefreshCw size={18} className="text-neutral-600" /></button>
        </div>

        {/* Address Bar */}
        <div className="flex-grow bg-neutral-200 rounded-full h-8 flex items-center px-3 space-x-2 min-w-0">
          <LuLock size={15} className="text-neutral-500 shrink-0" />
          <span className="text-sm text-neutral-700 flex-grow truncate" title="Gemini API - Main Page">gemini.google.com/app</span>
          <button className="p-0.5" aria-label="Bookmark this page"><LuStar size={16} className="text-neutral-500 hover:text-yellow-500 shrink-0" /></button>
        </div>

        {/* Extensions & Profile/Menu Area */}
        <div className="flex items-center space-x-0.5">
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Extension: Settings"><LuSettings2 size={19} className="text-neutral-600" /></button>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Extension: Security"><LuShield size={19} className="text-neutral-600" /></button>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Extension: Features"><LuPuzzle size={19} className="text-neutral-600" /></button>
            <div className="w-px h-5 bg-neutral-300 mx-1"></div>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Profile"><LuUserCircle2 size={20} className="text-neutral-600" /></button>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Menu"><LuMoreVertical size={20} className="text-neutral-600" /></button>
        </div>
      </div>
      
      {/* Content Area */}
      <div className="flex-grow bg-neutral-50 p-8 overflow-y-auto text-neutral-800">
        <h1 className="text-2xl font-semibold mb-4">Welcome to the Gemini API Showcase</h1>
        <p className="mb-3 text-sm leading-relaxed">
          This is a demonstration of a user interface built with React and Tailwind CSS,
          replicating some visual aspects of a modern operating system environment. The browser
          window you are currently viewing is a component within this larger application.
        </p>
        <p className="mb-3 text-sm leading-relaxed">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
          incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
          exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
          irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
          officia deserunt mollit anim id est laborum.
        </p>
        <p className="text-sm leading-relaxed">
          Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
          laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
          architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
          sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione
          voluptatem sequi nesciunt.
        </p>
      </div>
    </div>
  );
};

export default BrowserWindow;