
import React from 'react';

const RedTechLogo: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="redGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" style={{ stopColor: '#FF5E5E', stopOpacity: 1 }} />
        <stop offset="100%" style={{ stopColor: '#D92626', stopOpacity: 1 }} />
      </linearGradient>
       <filter id="dropShadow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
        <feOffset dx="2" dy="3" result="offsetblur"/>
        <feComponentTransfer>
          <feFuncA type="linear" slope="0.5"/>
        </feComponentTransfer>
        <feMerge> 
          <feMergeNode/>
          <feMergeNode in="SourceGraphic"/> 
        </feMerge>
      </filter>
    </defs>
    <g filter="url(#dropShadow)">
      <path d="M50 135 C10 135, 5 85, 5 75 C5 65, 10 15, 50 15" stroke="url(#redGradient)" strokeWidth="22" fill="none" strokeLinecap="round"/>
      <path d="M150 135 C190 135, 195 85, 195 75 C195 65, 190 15, 150 15" stroke="url(#redGradient)" strokeWidth="22" fill="none" strokeLinecap="round"/>
      
      <path d="M60 90 A35 35 0 0 1 140 90" stroke="url(#redGradient)" strokeWidth="20" fill="none" strokeLinecap="round"/>
      <path d="M60 60 A35 35 0 0 0 140 60" stroke="url(#redGradient)" strokeWidth="20" fill="none" strokeLinecap="round"/>
      
      <circle cx="100" cy="75" r="15" fill="url(#redGradient)" stroke="#A51A1A" strokeWidth="2"/>
      <rect x="90" y="71" width="20" height="8" fill="#B31D1D" rx="3" transform="rotate(5 100 75)"/>
    </g>
  </svg>
);

export default RedTechLogo;
