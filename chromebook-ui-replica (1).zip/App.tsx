
import React, { useState, useEffect } from 'react';
import { ShelfApp } from './types';
import ShelfItem from './components/ShelfItem';
import BrowserWindow from './components/BrowserWindow';
import ChromeLogoIcon from './components/ChromeLogoIcon';

// Lucide Icons (or placeholders)
import LuSearch from './components/icons/LuSearch';
import LuFolder from './components/icons/LuFolder';
import LuPlay from './components/icons/LuPlay';
import LuMail from './components/icons/LuMail';
import LuYoutube from './components/icons/LuYoutube';
import LuSettings2 from './components/icons/LuSettings2';
import LuChevronUp from './components/icons/LuChevronUp';
import LuWifi from './components/icons/LuWifi';
import LuBatteryFull from './components/icons/LuBatteryFull';


const App: React.FC = () => {
  const [currentTime, setCurrentTime] = useState('');
  const [activeApp, setActiveApp] = useState<string | null>('chrome'); // Chrome active by default

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);
    setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })); // Initial time
    return () => clearInterval(timer);
  }, []);

  const shelfApps: ShelfApp[] = [
    { id: 'chrome', name: 'Chrome', icon: <ChromeLogoIcon className="w-full h-full" />, active: activeApp === 'chrome' },
    { id: 'files', name: 'Files', icon: <LuFolder />, active: activeApp === 'files' },
    { id: 'playstore', name: 'Play Store', icon: <LuPlay className="text-green-400" />, active: activeApp === 'playstore' },
    { id: 'gmail', name: 'Gmail', icon: <LuMail className="text-red-500" />, active: activeApp === 'gmail' },
    { id: 'youtube', name: 'YouTube', icon: <LuYoutube className="w-full h-full" />, active: activeApp === 'youtube' },
    { id: 'settings', name: 'Settings', icon: <LuSettings2 />, active: activeApp === 'settings' },
  ];

  const handleAppClick = (appId: string) => {
    // In a real app, this would open/focus the app window.
    // For this demo, we just set it as active.
    setActiveApp(appId);
  };
  

  return (
    <div className="h-screen w-screen bg-slate-200 flex flex-col items-center justify-center overflow-hidden relative">
      {/* Desktop Wallpaper - could be an image */}
      <img src="https://picsum.photos/seed/chromebookdesktop/1920/1080" alt="Desktop Wallpaper" className="absolute inset-0 w-full h-full object-cover z-0" />
      <div className="absolute inset-0 bg-black/10 z-0"></div> {/* Slight overlay for wallpaper */}


      {/* Browser Window */}
      {activeApp === 'chrome' && <BrowserWindow />}
      {/* Placeholder for other app windows if implemented */}
      {/* {activeApp !== 'chrome' && activeApp !== null && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-72 bg-white rounded-lg shadow-xl p-4">
          <h2 className="text-xl font-semibold">{(shelfApps.find(app => app.id === activeApp))?.name}</h2>
          <p>Window for {activeApp}</p>
        </div>
      )} */}


      {/* Shelf */}
      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-auto max-w-[95vw] bg-black/60 backdrop-blur-md rounded-full px-3 py-1.5 shadow-2xl flex items-center space-x-1.5 z-10">
        {/* Launcher */}
        <button 
          aria-label="Launcher"
          title="Launcher"
          className="p-2.5 rounded-full hover:bg-white/20 focus:outline-none focus:bg-white/25 transition-colors"
        >
          <LuSearch className="w-6 h-6 text-white" />
        </button>

        {/* App Icons */}
        <div className="flex items-center space-x-1">
          {shelfApps.map(app => (
            <ShelfItem 
              key={app.id} 
              {...app}
              active={activeApp === app.id}
              onClick={() => handleAppClick(app.id)} 
            />
          ))}
        </div>
        
        <div className="h-6 w-px bg-white/20 mx-1"></div>

        {/* System Tray */}
        <div className="flex items-center space-x-3 text-white text-xs px-2">
          <button className="hover:bg-white/10 p-1 rounded-sm">
            <LuChevronUp className="w-4 h-4" />
          </button>
          <LuWifi className="w-4 h-4" />
          <LuBatteryFull className="w-5 h-5" />
          <span>{currentTime}</span>
        </div>
      </div>
    </div>
  );
};

export default App;
