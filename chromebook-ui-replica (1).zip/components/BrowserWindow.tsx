import React from 'react';
import ChromeLogoIcon from './ChromeLogoIcon';
import LuArrowLeft from './icons/LuArrowLeft';
import LuArrowRight from './icons/LuArrowRight';
import LuRefreshCw from './icons/LuRefreshCw';
import LuLock from './icons/LuLock';
import LuStar from './icons/LuStar';
import LuSettings2 from './icons/LuSettings2'; // Re-using for an extension icon
import LuShield from './icons/LuShield';
import LuPuzzle from './icons/LuPuzzle';
import LuUserCircle2 from './icons/LuUserCircle2';
import LuMoreVertical from './icons/LuMoreVertical';

const BrowserWindow: React.FC = () => {
  return (
    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[85vw] h-[80vh] max-w-[1200px] max-h-[800px] bg-white rounded-lg shadow-2xl flex flex-col overflow-hidden border border-gray-300">
      {/* Top Bar: Tabs + Window Controls */}
      <div className="bg-neutral-200 h-10 flex items-center px-1 shrink-0 border-b border-gray-300">
        {/* Active Tab */}
        <div className="bg-white px-4 py-1 h-full flex items-center rounded-t-md shadow-sm border-r border-l border-t border-gray-300 relative -mb-px mr-1 z-10">
          <ChromeLogoIcon className="w-4 h-4 mr-2 text-gray-600 shrink-0" />
          <span className="text-xs text-neutral-800 truncate">Gemini API Info</span>
          <button aria-label="Close tab" className="ml-3 text-xs text-gray-400 hover:text-gray-700 shrink-0">&times;</button>
        </div>
        {/* Placeholder for more tabs or new tab button */}
        {/* Window Controls */}
        <div className="ml-auto flex space-x-2 pr-2">
          <div className="w-3 h-3 bg-neutral-400 rounded-full hover:bg-neutral-500 cursor-pointer" aria-label="Minimize" role="button"></div>
          <div className="w-3 h-3 bg-neutral-400 rounded-full hover:bg-neutral-500 cursor-pointer" aria-label="Maximize" role="button"></div>
          <div className="w-3 h-3 bg-red-500 rounded-full hover:bg-red-600 cursor-pointer" aria-label="Close" role="button"></div>
        </div>
      </div>

      {/* Toolbar: Nav, Address, Extensions, Menu */}
      <div className="bg-neutral-100 h-11 flex items-center px-2 space-x-2 shrink-0 border-b border-gray-300">
        {/* Nav Buttons */}
        <div className="flex items-center space-x-0.5">
          <button className="p-1.5 rounded hover:bg-black/10" aria-label="Back"><LuArrowLeft size={18} className="text-neutral-600" /></button>
          <button className="p-1.5 rounded hover:bg-black/10" aria-label="Forward"><LuArrowRight size={18} className="text-neutral-600" /></button>
          <button className="p-1.5 rounded hover:bg-black/10" aria-label="Reload"><LuRefreshCw size={18} className="text-neutral-600" /></button>
        </div>

        {/* Address Bar */}
        <div className="flex-grow bg-neutral-200 rounded-full h-8 flex items-center px-3 space-x-2 min-w-0">
          <LuLock size={15} className="text-neutral-500 shrink-0" />
          <span className="text-sm text-neutral-700 flex-grow truncate" title="Gemini API - Main Page">gemini.google.com/app/info</span>
          <button className="p-0.5" aria-label="Bookmark this page"><LuStar size={16} className="text-neutral-500 hover:text-yellow-500 shrink-0" /></button>
        </div>

        {/* Extensions & Profile/Menu Area */}
        <div className="flex items-center space-x-0.5">
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Extension: Settings"><LuSettings2 size={19} className="text-neutral-600" /></button>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Extension: Security"><LuShield size={19} className="text-neutral-600" /></button>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Extension: Features"><LuPuzzle size={19} className="text-neutral-600" /></button>
            <div className="w-px h-5 bg-neutral-300 mx-1"></div>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Profile"><LuUserCircle2 size={20} className="text-neutral-600" /></button>
            <button className="p-1.5 rounded-full hover:bg-black/10" aria-label="Menu"><LuMoreVertical size={20} className="text-neutral-600" /></button>
        </div>
      </div>
      
      {/* Content Area */}
      <div className="flex-grow bg-neutral-50 p-8 overflow-y-auto text-neutral-800">
        <h1 className="text-3xl font-semibold mb-6 text-slate-700">Welcome to the Gemini API Showcase</h1>
        <p className="mb-4 text-base leading-relaxed">
          This interactive demonstration highlights a user interface built with React and Tailwind CSS,
          designed to replicate key visual elements of a modern operating system environment. The browser
          window you are currently viewing is a central component, showcasing how dynamic content can be
          presented.
        </p>
        <p className="mb-6 text-base leading-relaxed">
          The Gemini API empowers developers to build next-generation applications with powerful
          generative AI capabilities. Explore the potential for creating intelligent, responsive,
          and highly personalized user experiences.
        </p>

        <hr className="my-8 border-t border-neutral-300" />

        <h2 className="text-2xl font-semibold mb-4 text-slate-600">Key Capabilities</h2>
        <p className="mb-5 text-base leading-relaxed">
          The Gemini family of models offers a range of functionalities. Here are some of the highlights:
        </p>
        <ul className="list-disc list-inside mb-6 space-y-2 text-base text-neutral-700">
          <li>
            <span className="font-medium">Advanced Text Generation:</span> Create coherent and contextually relevant text for various applications, from creative writing to summarization.
          </li>
          <li>
            <span className="font-medium">Multimodal Understanding:</span> Process and understand information from different modalities, including text, images, and more, enabling richer interactions.
          </li>
          <li>
            <span className="font-medium">Efficient Performance:</span> Optimized for a balance of speed and quality, allowing for responsive AI-powered features in your applications.
          </li>
          <li>
            <span className="font-medium">Customizable and Controllable:</span> Fine-tune model behavior and outputs to suit specific needs and ensure responsible AI practices.
          </li>
        </ul>
        
        <p className="mb-4 text-base leading-relaxed">
          This demonstration aims to provide a glimpse into how such an API could be integrated into a
          familiar user interface. The elements you see, from the shelf to this browser window, are
          all part of this simulated environment.
        </p>
        <p className="text-base leading-relaxed">
          Dive deeper into the documentation and examples to fully harness the power of the Gemini API
          for your own projects.
        </p>
      </div>
    </div>
  );
};

export default BrowserWindow;