
import React from 'react';

const ChromeLogoIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="10" fill="#4285F4"/>
    <circle cx="12" cy="12" r="5.5" fill="white"/>
    <path d="M12 2A10 10 0 005.121 6.361l7.071 7.071A9.961 9.961 0 0021.314 12.5H12V2z" fill="#DB4437"/>
    <path d="M2 12a10 10 0 004.361 8.121l7.071-7.071A9.961 9.961 0 0011.5 2.686V12H2z" fill="#F4B400"/>
    <path d="M12 22A10 10 0 0018.879 17.639l-7.071-7.071A9.961 9.961 0 002.686 11.5H12v10.5z" fill="#0F9D58"/>
  </svg>
);

export default ChromeLogoIcon;
