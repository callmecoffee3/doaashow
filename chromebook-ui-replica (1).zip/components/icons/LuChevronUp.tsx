
import React from 'react';
import LuIconBase from './LuIconBase';

const LuChevronUp: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <LuIconBase {...props}>
    <polyline points="18 15 12 9 6 15" />
  </LuIconBase>
);

export default LuChevronUp;
