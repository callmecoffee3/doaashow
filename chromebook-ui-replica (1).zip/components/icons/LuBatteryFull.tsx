
import React from 'react';
import LuIconBase from './LuIconBase';

const LuBatteryFull: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <LuIconBase {...props}>
    <rect x="2" y="7" width="16" height="10" rx="2" ry="2" />
    <line x1="22" y1="11" x2="22" y2="13" />
    <line x1="6" y1="12" x2="6" y2="12" />
    <line x1="10" y1="12" x2="10" y2="12" />
     <line x1="14" y1="12" x2="14" y2="12" />
  </LuIconBase>
);

export default LuBatteryFull;
