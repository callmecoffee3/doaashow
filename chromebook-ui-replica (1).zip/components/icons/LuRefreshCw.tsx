import React from 'react';
import LuIconBase from './LuIconBase';

const LuRefreshCw: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <LuIconBase {...props}>
    <path d="M21 2v6h-6" />
    <path d="M3 12A9 9 0 0 1 15 5.3L15 3" />
    <path d="M3 22v-6h6" />
    <path d="M21 12A9 9 0 0 1 9 18.7L9 21" />
  </LuIconBase>
);

export default LuRefreshCw;