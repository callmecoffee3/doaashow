import React from 'react';
import LuIconBase from './LuIconBase';

const LuPuzzle: React.FC<React.SVGAttributes<SVGElement>> = (props) => (
  <LuIconBase {...props}>
    <path d="M19.439 7.439A2.001 2.001 0 0 0 18 6.586V4.5a2 2 0 0 0-2-2h-1.586a2 2 0 0 0-1.414.586L9.414 6.586A2 2 0 0 0 8 7.414V9.5a2 2 0 0 0 2 2h1.586a2 2 0 0 0 1.414-.586L16.586 7.414A2 2 0 0 0 18 6.586V4.5" />
    <path d="m9.414 14.586-3-3a2 2 0 0 0-2.828 0L2.172 12.9a2.002 2.002 0 0 0 0 2.828L4.586 18a2 2 0 0 0 2.828 0l3-3" />
    <path d="m14.586 9.414 3 3a2 2 0 0 1 0 2.828l-1.414 1.414a2 2 0 0 1-2.828 0l-3-3" />
     <path d="M21.172 11.172a2.002 2.002 0 0 0-2.828 0L15.414 14a2 2 0 0 0 0 2.828l2.314 2.314a2 2 0 0 0 2.828 0l.23-.23a2 2 0 0 0 .586-1.414V12a2 2 0 0 0-.2-.828Z" />
  </LuIconBase>
);

export default LuPuzzle;