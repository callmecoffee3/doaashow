
import React from 'react';
import { ShelfApp } from '../types';

const ShelfItem: React.FC<ShelfApp> = ({ icon, name, onClick, active }) => {
  return (
    <button
      onClick={onClick}
      aria-label={name}
      title={name}
      className={`p-2.5 rounded-full hover:bg-white/20 focus:outline-none focus:bg-white/25 transition-all duration-150 ease-in-out relative ${active ? 'bg-white/15' : ''}`}
    >
      <div className="w-7 h-7 text-white flex items-center justify-center">
        {icon}
      </div>
      {active && <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 bg-white rounded-full mb-[-8px]"></div>}
    </button>
  );
};

export default ShelfItem;
