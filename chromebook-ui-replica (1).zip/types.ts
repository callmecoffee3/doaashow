
import React from 'react';

export interface ShelfApp {
  id: string;
  name: string;
  icon: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
}
