#!/usr/bin/env python3
"""
mattgrosso_agent.py
~~~~~~~~~~~~~~~~~~~
A tiny CLI “agent” that turns raw story ingredients into index‑card notes.

Features
--------
* Accepts a free‑form list of story elements (characters, scenes, themes, …)
* Optionally tags each element with a type (e.g. [CHAR] Detective …) or lets the
  script infer a type from a built‑in keyword map.
* Can sort, limit, and output as plain text, Markdown table or JSON.
* Writes a changelog so you can track revisions.
* Can launch the resulting file in VS Code (if `code` is on PATH).

Usage examples are shown at the bottom of the file.
"""

import argparse
import json
import os
import re
import sys
import subprocess
from datetime import datetime
from pathlib import Path
from typing import List, Tuple, Dict, Optional

@echo off
REM ==============================================================
REM  mattgrosso agent – slowed down for comfortable reading
REM  Adjust the number after --delay to make it faster/slower.
REM  %* passes all arguments you give the .bat straight to the script.
REM ==============================================================

REM ---- Set the delay (seconds) you want between each token ----
REM 0.0 = no delay, 0.2‑0.5 = comfortable reading, 1.0+ = very deliberate
set "DELAY=0.5"

REM ---- Run the Python script, appending the delay flag ----
REM    %~dp0 expands to the directory where this .bat lives,
REM    so the script is found even if you launch the .bat from elsewhere.
python "%~dp0mattgrosso_agent.py" %* --delay %DELAY%

REM ---- Keep the window open after the script finishes (optional) ----
REM    Remove the line below if you prefer the window to close automatically.
pause

# ----------------------------------------------------------------------
# 0        Default slow‑down (seconds). Change this value to suit you.
# ----------------------------------------------------------------------
DEFAULT_DELAY = 0.5   # ← set to 0.0 for no pause, 0.2‑0.8 for a comfortable read

# ----------------------------------------------------------------------
# 1        Type inference map – feel free to extend
# ----------------------------------------------------------------------
TYPE_KEYWORDS: Dict[str, List[str]] = {
    "CHAR": [
        "character", "protagonist", "antagonist", "hero", "villain",
        "detective", "spy", "doctor", "teacher", "parent", "child",
        "detective", "agent", "officer", "captain", "king", "queen",
    ],
    "SCENE": [
        "scene", "setting", "location", "place", "room", "street",
        "alley", "office", "apartment", "house", "forest", "city",
        "town", "village", "spaceship", "planet", "castle", "lab",
    ],
    "BEAT": [
        "beat", "plot point", "inciting incident", "midpoint",
        "climax", "resolution", "twist", "reveal", "flashback",
        "foreshadowing", "montage", "voiceover", "narration",
        "monologue", "dialogue", "dialogue tag",
    ],
    "THEME": [
        "theme", "motif", "symbol", "allegory", "metaphor", "irony",
        "satire", "parody", "message", "lesson", "moral",
    ],
    "TONE": [
        "tone", "mood", "atmosphere", "feel", "style", "voice",
    ],
    "GENRE": [
        "genre", "category", "type", "style", "noir", "thriller",
        "horror", "comedy", "drama", "sci‑fi", "fantasy", "romance",
        "action", "adventure",
    ],
    "FORMAT": [
        "format", "medium", "film", "tv", "series", "episode",
        "short", "feature", "mini‑series", "webseries",
    ],
    "LENGTH": [
        "length", "runtime", "minutes", "hours", "episodes",
    ],
    "STYLE": [
        "style", "aesthetic", "look", "visual", "cinematography",
    ],
    "AUDIENCE": [
        "audience", "demographic", "viewers", "readers", "players",
    ],
    "CONFLICT": [
        "conflict", "problem", "obstacle", "antagonism", "struggle",
    ],
    "RESOLUTION": [
        "resolution", "solution", "conclusion", "ending",
    ],
    "PACING": [
        "pacing", "tempo", "rhythm", "speed",
    ],
    "STRUCTURE": [
        "structure", "act", "act i", "act ii", "act iii",
        "three‑act", "five‑act", "story arc", "subplot",
    ],
    "VISUALS": [
        "visuals", "imagery", "picture", "shot", "frame",
    ],
    "SOUND": [
        "sound", "sound design", "fx", "effects", "music",
    ],
    "MUSIC": [
        "music", "score", "song", "theme song", "cue",
    ],
    "CAMERA": [
        "camera", "angle", "shot", "pan", "tilt", "zoom",
    ],
    "LIGHTING": [
        "lighting", "light", "shadow", "glow", "silhouette",
    ],
    "COSTUMES": [
        "costume", "wardrobe", "outfit", "clothing",
    ],
    "PROPS": [
        "prop", "object", "item", "artifact",
    ],
    "SFX": [
        "special effect", "vfx", "practical effect", "explosion",
    ],
    "SEASONS": [
        "season", "season 1", "season 2", "episode",
    ],
    "TITLES": [
        "title", "working title", "logline",
    ],
    "EPISODES": [
        "episode", "ep", "part",
    ],
    "ACTS": [
        "act", "act i", "act ii", "act iii",
    ],
    "BEATS": [
        "beat", "beat", "scene beat",
    ],
    "STORY_ARCS": [
        "story arc", "arc",
    ],
    "SUBPLOTS": [
        "subplot", "b‑story",
    ],
    "TWISTS": [
        "twist", "reveal", "plot twist",
    ],
    "CLIFFHANGERS": [
        "cliffhanger", "cliff",
    ],
    "FORESHADOWING": [
        "foreshadowing", "foreshadow",
    ],
    "FLASHBACKS": [
        "flashback", "flash back",
    ],
    "MONTAGES": [
        "montage", "montage sequence",
    ],
    "VOICEOVERS": [
        "voice over", "voiceover",
    ],
    "NARRATION": [
        "narration", "narrator",
    ],
    "MONOLOGUES": [
        "monologue", "soliloquy",
    ],
    "CHAR_DEV": [
        "character development", "arc", "growth",
    ],
    "EMOTIONAL_BEATS": [
        "emotional beat", "feeling", "emotion",
    ],
    "THEMES_MOTIFS": [
        "theme", "motif",
    ],
    "SYMBOLISM": [
        "symbolism", "symbol",
    ],
    "ALLEGORY": [
        "allegory",
    ],
    "METAPHOR": [
        "metaphor",
    ],
    "IRONY": [
        "irony",
    ],
    "SATIRE": [
        "satire",
    ],
    "PARODY": [
        "parody",
    ],
    "COMEDY_TIMING": [
        "comedy timing", "timing",
    ],
    "DRAMATIC_TENSION": [
        "dramatic tension", "tension",
    ],
    "SUSPENSE_BUILDING": [
        "suspense", "suspense building",
    ],
    "HORROR_ELEMENTS": [
        "horror", "gore", "scare",
    ],
    "THRILLER_PACING": [
        "thriller pacing",
    ],
    "ROMANTIC_TENSION": [
        "romantic tension", "chemistry",
    ],
    "ACTION_SEQUENCES": [
        "action sequence", "fight", "chase",
    ],
    "FIGHT_CHOREOGRAPHY": [
        "fight choreography", "martial arts",
    ],
    "STUNT_COORDINATION": [
        "stunt coordination", "stunt",
    ],
    "SFX_PLANNING": [
        "special effects planning", "sfx plan",
    ],
}

def infer_type(token: str) -> str:
    """
    Return the most likely TYPE for a free‑form token.
    If no keyword matches, fall back to 'NOTE'.
    """
    lowered = token.lower()
    for typ, keywords in TYPE_KEYWORDS.items():
        for kw in keywords:
            if kw in lowered:
                return typ
    return "NOTE"

def parse_card_token(token: str) -> Tuple[str, str]:
    """
    Split a token into (type, summary).
    If token already contains a leading tag like [CHAR] ... we honour it.
    Otherwise we infer a type.
    Returns the TYPE in uppercase and the cleaned summary string.
    """
    token = token.strip()
    # Check for an explicit tag like [CHAR] or [SCENE]
    m = re.match(r'^\s*\[([^\]]+)\]\s*(.+)$', token)
    if m:
        typ = m.group(1).strip().upper()
        summary = m.group(2).strip()
        return typ, summary
    # No explicit tag – infer
    typ = infer_type(token)
    return typ, token

def build_cards(raw_items: List[str]) -> List[Dict[str, str]]:
    """
    Turn a list of raw strings into a list of dicts:
        {"type": "...", "summary": "..."}
    """
    cards = []
    for item in raw_items:
        if not item:
            continue
        typ, summary = parse_card_token(item)
        cards.append({"type": typ, "summary": summary})
    return cards

# ----------------------------------------------------------------------
# 2        Sorting helpers
# ----------------------------------------------------------------------
def sort_cards(cards: List[Dict[str, str]], mode: str) -> List[Dict[str, str]]:
    if mode == "none" or not cards:
        return cards
    if mode == "act":
        # Prefer cards whose type contains ACT or whose summary mentions an act number
        def act_key(c):
            summary = c["summary"].lower()
            # Look for patterns like "act i", "act 2", etc.
            m = re.search(r'act\s*[ivx]+|\s*\d+\s*', summary)
            if m:
                # Convert roman/arabic to int for sorting (simple fallback)
                num_str = m.group(0).replace('act', '').strip()
                try:
                    return int(num_str)
                except ValueError:
                    # roman numeral conversion (very basic)
                    roman = {'i':1,'ii':2,'iii':3,'iv':4,'v':5,'vi':6,'vii':7,'viii':8,'ix':9,'x':10}
                    return roman.get(num_str.lower(), 0)
            return 0
        return sorted(cards, key=act_key)
    if mode == "chron":
        # Try to pull a year or time‑of‑day from the summary
        def chron_key(c):
            # Look for four‑digit year
            m = re.search(r'\b(19|20)\d{2}\b', c["summary"])
            if m:
                return int(m.group(0))
            # Look for time like "2 a.m." or "14:30"
            m = re.search(r'\b(\d{1,2})\s*[:h]\s*(\d{2})?\s*([ap]m)?\b', c["summary"], re.I)
            if m:
                hour = int(m.group(1))
                if m.group(3):
                    if m.group(3).lower() == 'p' and hour != 12:
                        hour += 12
                    if m.group(3).lower() == 'a' and hour == 12:
                        hour = 0
                return hour * 60 + (int(m.group(2)) if m.group(2) else 0)
            return 0
        return sorted(cards, key=chron_key)
    if mode == "theme":
        # Group by TYPE first, then alphabetical summary
        return sorted(cards, key=lambda c: (c["type"], c["summary"].lower()))
    # fallback: original order
    return cards

# ----------------------------------------------------------------------
# 3        Output formatters
# ----------------------------------------------------------------------
def format_plain(cards: List[Dict[str, str]]) -> str:
    lines = [f"{c['type']} – {c['summary']}" for c in cards]
    return "\n".join(lines)

def format_markdown(cards: List[Dict[str, str]]) -> str:
    header = "| Type | Summary |\n|------|---------|"
    rows = [f"| {c['type']} | {c['summary']} |" for c in cards]
    return "\n".join([header] + rows)

def format_json(cards: List[Dict[str, str]]) -> str:
    return json.dumps(cards, indent=2, ensure_ascii=False)

FORMATTERS = {
    "plain": format_plain,
    "markdown": format_markdown,
    "json": format_json,
}

# ----------------------------------------------------------------------
# 4        Changelog handling
# ----------------------------------------------------------------------
def write_changelog(changelog_path: Path, output_path: Path, cards: List[Dict[str, str]]) -> None:
    """Append a timestamped entry describing what was written."""
    timestamp = datetime.now().isoformat(timespec='seconds')
    entry = f"[{timestamp}] Generated {len(cards)} cards → {output_path.name}\n"
    try:
        with changelog_path.open("a", encoding="utf-8") as f:
            f.write(entry)
    except OSError:
        # If we can't write the changelog we just silently ignore – not fatal.
        pass

# ----------------------------------------------------------------------
# 5        Main CLI
# ----------------------------------------------------------------------
def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="mattgrosso agent – turn story ingredients into index‑card notes.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  echo 'detective, rain‑slick alley, trust vs betrayal' | mattgrosso_agent.py\n"
            "  mattgrosso_agent.py --input 'characters: Lena, scenes: precinct' --format markdown --open\n"
            "  mattgrosso_agent.py @ideas.txt --format json --max-cards 10 --verbose\n"
        )
    )
    parser.add_argument(
        "inputs",
        nargs="*",
        help="Raw story items. Can be plain text, comma‑separated, or newline‑separated. "
             "You may also prefix with a type tag like [CHAR] Detective …"
    )
    parser.add_argument(
        "-i", "--input",
        dest="input_str",
        help="Alternative way to supply a single string of items (useful for quoting)."
    )
    parser.add_argument(
        "-f", "--format",
        choices=["plain", "markdown", "json"],
        default="markdown",
        help="Output format (default: markdown)."
    )
    parser.add_argument(
        "-s", "--sort",
        choices=["none", "act", "chron", "theme"],
        default="none",
        help="How to order the cards (default: none – keep input order)."
    )
    parser.add_argument(
        "-m", "--max-cards",
        type=int,
        help="Limit output to the first N cards after sorting."
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Print internal reasoning (type inference, sorting, etc.) to stderr."
    )
    parser.add_argument(
        "-o", "--out",
        type=Path,
        help="Write output to FILE instead of stdout. If omitted, prints to stdout."
    )
    parser.add_argument(
        "--open",
        action="store_true",
        help="After writing, open the file in VS Code (if `code` is on PATH)."
    )
    args = parser.parse_args(argv)

    # ------------------------------------------------------------------
    # Gather raw tokens from positional args + optional --input string
    # ------------------------------------------------------------------
    raw_tokens: List[str] = []
    if args.inputs:
        raw_tokens.extend(args.inputs)
    if args.input_str:
        raw_tokens.append(args.input_str)

    # Flatten possible comma / newline separation
    flattened: List[str] = []
    for token in raw_tokens:
        # Split on commas or newlines, keep non‑empty pieces
        parts = re.split(r'[\r\n,]+', token)
        flattened.extend([p.strip() for p in parts if p.strip()])

    if not flattened:
        parser.error("No input supplied. Provide items via arguments or --input.")

    if args.verbose:
        print(f"[VERBOSE] Received {len(flattened)} raw token(s)", file=sys.stderr)

    # ------------------------------------------------------------------
    # Build cards
    # ------------------------------------------------------------------
    cards = build_cards(flattened)
    if args.verbose:
        print(f"[VERBOSE] Built {len(cards)} cards", file=sys.stderr)
        for c in cards:
            print(f"[VERBOSE]   {c['type']}: {c['summary']}", file=sys.stderr)

    # ------------------------------------------------------------------
    # Sort / limit
    # ------------------------------------------------------------------
    cards = sort_cards(cards, args.sort)
    if args.verbose:
        print(f"[VERBOSE] Sorted by '{args.sort}'", file=sys.stderr)
    if args.max_cards is not None:
        cards = cards[: args.max_cards]
        if args.verbose:
            print(f"[VERBOSE] Limited to first {args.max_cards} cards", file=sys.stderr)

    # ------------------------------------------------------------------
    # Format output
    # ------------------------------------------------------------------
    formatter = FORMATTERS[args.format]
    output_text = formatter(cards)

    # ------------------------------------------------------------------
    # Determine output destination
    # ------------------------------------------------------------------
    if args.out:
        out_path = args.out.expanduser().resolve()
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(output_text + "\n", encoding="utf-8")
            if args.verbose:
                print(f"[VERBOSE] Wrote output to {out_path}", file=sys.stderr)
        except OSError as e:
            parser.error(f"Cannot write to {out_path}: {e}")
        # Write changelog next to the output file
        changelog_path = out_path.with_name(out_path.name + ".changelog")
        write_changelog(changelog_path, out_path, cards)
        # Optionally open in VS Code
        if args.open:
            try:
                subprocess.run(["code", str(out_path)], check=False)
                if args.verbose:
                    print(f"[VERBOSE] Launched VS Code on {out_path}", file=sys.stderr)
            except FileNotFoundError:
                if args.verbose:
                    print("[VERBOSE] VS Code (`code`) not found in PATH – skipping open.", file=sys.stderr)
    else:
        # stdout
        sys.stdout.write(output_text + "\n")
        # Still write a changelog in the current working directory for posterity
        changelog_path = Path(".mattgrosso.changelog")
        write_changelog(changelog_path, Path("<stdout>"), cards)

    return 0

if __name__ == "__main__":
    sys.exit(main())
