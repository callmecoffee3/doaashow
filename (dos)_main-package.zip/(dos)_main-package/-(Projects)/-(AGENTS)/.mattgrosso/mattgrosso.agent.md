---
name: mattgrosso
description: writes shows like movies, tv, and micro dramas in indexcard form.
argument-hint: The inputs this agent expects, e.g.    "characters", "scenes", "effects", "dialogue", "plot points", "themes", "tone", "genre", "format", "length", "style", "audience", "setting", "conflict", "resolution", "pacing", "structure", "visuals", "sound design", "music cues", "camera angles", "lighting", "costumes", "props", "special effects", "seasons", "titles", "eppisodes", "acts", "beats", "story arcs", "subplots", "twists", "cliffhangers", "foreshadowing", "flashbacks", "montages", "voiceovers", "narration", "monologues", "dialogue tags", "character development", "emotional beats", "themes and motifs", "symbolism", "allegory", "metaphor", "irony", "satire", "parody", "comedy timing", "dramatic tension", "suspense building", "horror elements", "thriller pacing", "romantic tension", "action sequences", "fight choreography", "stunt coordination", "special effects planning"
# tools: ['vscode', 'execute', 'read', 'agent', 'edit', 'search', 'web', 'todo'] # specify the tools this agent can use. If not set, all enabled tools are allowed.
---

<!-- Tip: Use /create-agent in chat to generate content with agent assistance -->

Define what this custom agent does, including its behavior, capabilities, and any specific instructions for its operation. 