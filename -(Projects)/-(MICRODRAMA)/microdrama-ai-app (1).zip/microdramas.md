# MicroDrama AI — Story Bible

> Big Drama. Small Screen.

---

## Structure

```
Projects          ← Add / Edit / Delete
 └── Decks         ← Add / Edit / Delete
      └── Index Cards
           ├── Character   ← Add / Edit / Delete
           ├── Scene       ← Add / Edit / Delete
           ├── Prop        ← Add / Edit / Delete
           ├── Animal      ← Add / Edit / Delete
           └── Prompt      ← Add / Edit / Delete
```

### Project actions
- **Add** — Create a new project from the Projects page
- **Edit** — Rename any project (hover → pencil icon)
- **Delete** — Remove a project and all its decks & cards (hover → trash icon)

### Deck actions
- **Add** — Create a new deck inside a project
- **Edit** — Rename any deck (hover → pencil icon)
- **Delete** — Remove a deck and all its cards (hover → trash icon)

### Index Card actions
- **Add** — Use the colored buttons (Character / Scene / Prop / Animal / Prompt)
- **Edit** — Hover a card → pencil icon
- **Delete** — Hover a card → trash icon

---

## Sample Project

### 📁 Project: Secret Wife Romance

#### 🃏 Deck: Main Story Deck

---

### Characters

#### Elena
- **Type:** Character  
- **Details:** Female, 24  
- **Description:** Poor but kind-hearted young woman working as a secretary. Soft-spoken, determined.

#### Mr. Kane
- **Type:** Character  
- **Details:** Male, 32  
- **Description:** Cold, ruthless CEO of a tech empire. Hides a soft side from his past.

---

### Scenes

#### Office Confession
- **Type:** Scene  
- **Location / Time:** Night, Office  
- **Description:** Late night in the glass office. Rain outside. Elena confronts Kane about the marriage certificate.

---

### Props

#### Fake Marriage Certificate
- **Type:** Prop  
- **Description:** A forged document that starts the whole conflict.

---

### Animals

#### Black Cat (Shadow)
- **Type:** Animal  
- **Species:** Cat  
- **Description:** Kane's quiet companion that only appears when he is vulnerable.

---

### Prompts

#### Core Hook
- **Type:** Prompt  
- **Description:** A poor girl is forced into a contract marriage with a cold CEO who turns out to be the boy who saved her life 10 years ago.

---

## How to use

1. Open **Workspace** → select or create a **Project**
2. Create **Decks** inside the project
3. Add **Index Cards** (Characters, Scenes, Props, Animals, Prompts)
4. Hover any project, deck, or card to **edit** or **delete** it
5. Go to **AI Studio**
6. Optionally check **"Include active project cards in generation"**
7. Write a prompt (or leave blank to use the Core Hook)
8. Generate your micro drama

---

## Card Types Reference

| Type       | Purpose                              | Extra Field              |
|------------|--------------------------------------|--------------------------|
| Character  | People in the story                  | Gender / Age / Role      |
| Scene      | Key locations & moments              | Location / Time          |
| Prop       | Important objects                    | —                        |
| Animal     | Pets or symbolic creatures           | Species                  |
| Prompt     | Story hooks / loglines / ideas       | —                        |

---

*Generated from MicroDrama AI • 2026*
