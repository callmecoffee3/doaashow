import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, chatbots, chatMessages } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createChatbot(userId: number, data: { name: string; description?: string; avatar?: string; systemPrompt: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(chatbots).values({
    userId,
    name: data.name,
    description: data.description,
    avatar: data.avatar,
    systemPrompt: data.systemPrompt,
  });
  
  return result;
}

export async function getChatbotsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(chatbots).where(eq(chatbots.userId, userId));
}

export async function getChatbotById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(chatbots).where(eq(chatbots.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateChatbot(id: number, data: { name?: string; description?: string; avatar?: string; systemPrompt?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updates: Record<string, unknown> = {};
  if (data.name !== undefined) updates.name = data.name;
  if (data.description !== undefined) updates.description = data.description;
  if (data.avatar !== undefined) updates.avatar = data.avatar;
  if (data.systemPrompt !== undefined) updates.systemPrompt = data.systemPrompt;
  
  return await db.update(chatbots).set(updates).where(eq(chatbots.id, id));
}

export async function deleteChatbot(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Delete associated messages first
  await db.delete(chatMessages).where(eq(chatMessages.chatbotId, id));
  // Then delete the chatbot
  return await db.delete(chatbots).where(eq(chatbots.id, id));
}

export async function saveChatMessage(chatbotId: number, role: "user" | "assistant", content: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(chatMessages).values({
    chatbotId,
    role,
    content,
  });
}

export async function getChatHistory(chatbotId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(chatMessages).where(eq(chatMessages.chatbotId, chatbotId));
}

export async function clearChatHistory(chatbotId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.delete(chatMessages).where(eq(chatMessages.chatbotId, chatbotId));
}
