import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chatbots: router({
    list: protectedProcedure.query(({ ctx }) =>
      db.getChatbotsByUserId(ctx.user.id)
    ),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const chatbot = await db.getChatbotById(input.id);
        return chatbot;
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1, "Name is required"),
        description: z.string().optional(),
        avatar: z.string().optional(),
        systemPrompt: z.string().min(1, "System prompt is required"),
      }))
      .mutation(({ ctx, input }) =>
        db.createChatbot(ctx.user.id, input)
      ),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        avatar: z.string().optional(),
        systemPrompt: z.string().optional(),
      }))
      .mutation(({ input }) =>
        db.updateChatbot(input.id, {
          name: input.name,
          description: input.description,
          avatar: input.avatar,
          systemPrompt: input.systemPrompt,
        })
      ),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) =>
        db.deleteChatbot(input.id)
      ),

    getChatHistory: protectedProcedure
      .input(z.object({ chatbotId: z.number() }))
      .query(({ input }) =>
        db.getChatHistory(input.chatbotId)
      ),

    clearChatHistory: protectedProcedure
      .input(z.object({ chatbotId: z.number() }))
      .mutation(({ input }) =>
        db.clearChatHistory(input.chatbotId)
      ),

    sendMessage: protectedProcedure
      .input(z.object({
        chatbotId: z.number(),
        userMessage: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        // Save user message
        await db.saveChatMessage(input.chatbotId, "user", input.userMessage);

        // Get chatbot to retrieve system prompt
        const chatbot = await db.getChatbotById(input.chatbotId);
        if (!chatbot) throw new Error("Chatbot not found");

        // Get chat history for context
        const history = await db.getChatHistory(input.chatbotId);

        // For now, return a mock response (will integrate with LLM later)
        const assistantMessage = `[Mock Response] I'm ${chatbot.name}. You said: "${input.userMessage}"`;

        // Save assistant message
        await db.saveChatMessage(input.chatbotId, "assistant", assistantMessage);

        return {
          userMessage: input.userMessage,
          assistantMessage,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
