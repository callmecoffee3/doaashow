import { Chatbot } from "@shared/types";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface EditChatbotFormProps {
  chatbot: Chatbot;
  onClose: () => void;
}

export default function EditChatbotForm({
  chatbot,
  onClose,
}: EditChatbotFormProps) {
  const [name, setName] = useState(chatbot.name);
  const [avatar, setAvatar] = useState(chatbot.avatar || "🤖");
  const [description, setDescription] = useState(chatbot.description || "");
  const [systemPrompt, setSystemPrompt] = useState(chatbot.systemPrompt);

  const updateMutation = trpc.chatbots.update.useMutation({
    onSuccess: () => {
      toast.success("Chatbot updated successfully!");
      onClose();
    },
    onError: (error) => {
      toast.error(`Failed to update: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      toast.error("Name is required");
      return;
    }

    if (!systemPrompt.trim()) {
      toast.error("System prompt is required");
      return;
    }

    updateMutation.mutate({
      id: chatbot.id,
      name: name.trim(),
      avatar: avatar || "🤖",
      description: description.trim(),
      systemPrompt: systemPrompt.trim(),
    });
  };

  return (
    <div className="dialog-overlay-brutalist" onClick={onClose}>
      <div
        className="dialog-content-brutalist max-w-4xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-4xl font-black uppercase mb-6">
          <span className="bracket-left">EDIT</span> CHATBOT
        </h2>

        <div className="separator-thick mb-6"></div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name Field */}
          <div>
            <label className="label-brutalist">Chatbot Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="input-brutalist"
              disabled={updateMutation.isPending}
            />
          </div>

          {/* Avatar Field */}
          <div>
            <label className="label-brutalist">Avatar / Emoji</label>
            <input
              type="text"
              value={avatar}
              onChange={(e) => setAvatar(e.target.value)}
              className="input-brutalist"
              maxLength={2}
              disabled={updateMutation.isPending}
            />
          </div>

          {/* Description Field */}
          <div>
            <label className="label-brutalist">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="textarea-brutalist h-20"
              disabled={updateMutation.isPending}
            />
          </div>

          {/* System Prompt Field */}
          <div>
            <label className="label-brutalist">System Prompt</label>
            <textarea
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              className="textarea-brutalist h-40"
              disabled={updateMutation.isPending}
            />
          </div>

          <div className="separator-thick"></div>

          {/* Buttons */}
          <div className="flex gap-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 btn-brutalist"
              disabled={updateMutation.isPending}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 btn-brutalist-primary"
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? "Saving..." : "Save Changes"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
