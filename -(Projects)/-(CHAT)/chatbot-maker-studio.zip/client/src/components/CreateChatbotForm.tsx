import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface CreateChatbotFormProps {
  onClose: () => void;
}

export default function CreateChatbotForm({ onClose }: CreateChatbotFormProps) {
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState("🤖");
  const [description, setDescription] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");

  const createMutation = trpc.chatbots.create.useMutation({
    onSuccess: () => {
      toast.success("Chatbot created successfully!");
      onClose();
    },
    onError: (error) => {
      toast.error(`Failed to create: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      toast.error("Name is required");
      return;
    }

    if (!systemPrompt.trim()) {
      toast.error("System prompt is required");
      return;
    }

    createMutation.mutate({
      name: name.trim(),
      avatar: avatar || "🤖",
      description: description.trim(),
      systemPrompt: systemPrompt.trim(),
    });
  };

  return (
    <div className="dialog-overlay-brutalist" onClick={onClose}>
      <div
        className="dialog-content-brutalist max-w-4xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-4xl font-black uppercase mb-6">
          <span className="bracket-left">CREATE</span> CHATBOT
        </h2>

        <div className="separator-thick mb-6"></div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name Field */}
          <div>
            <label className="label-brutalist">Chatbot Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Creative Writer"
              className="input-brutalist"
              disabled={createMutation.isPending}
            />
          </div>

          {/* Avatar Field */}
          <div>
            <label className="label-brutalist">Avatar / Emoji</label>
            <input
              type="text"
              value={avatar}
              onChange={(e) => setAvatar(e.target.value)}
              placeholder="🤖"
              className="input-brutalist"
              maxLength={2}
              disabled={createMutation.isPending}
            />
          </div>

          {/* Description Field */}
          <div>
            <label className="label-brutalist">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does this chatbot do?"
              className="textarea-brutalist h-20"
              disabled={createMutation.isPending}
            />
          </div>

          {/* System Prompt Field */}
          <div>
            <label className="label-brutalist">System Prompt</label>
            <textarea
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              placeholder="Define the chatbot's behavior, personality, and instructions..."
              className="textarea-brutalist h-40"
              disabled={createMutation.isPending}
            />
          </div>

          <div className="separator-thick"></div>

          {/* Buttons */}
          <div className="flex gap-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 btn-brutalist"
              disabled={createMutation.isPending}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 btn-brutalist-primary"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? "Creating..." : "Create Chatbot"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
