import { Chatbot } from "@shared/types";
import { useState } from "react";

interface DeleteConfirmDialogProps {
  chatbot: Chatbot;
  onConfirm: () => void;
  onCancel: () => void;
  isLoading: boolean;
}

export default function DeleteConfirmDialog({
  chatbot,
  onConfirm,
  onCancel,
  isLoading,
}: DeleteConfirmDialogProps) {
  const [confirmText, setConfirmText] = useState("");
  const isConfirmed = confirmText === chatbot.name;

  return (
    <div className="dialog-overlay-brutalist" onClick={onCancel}>
      <div
        className="dialog-content-brutalist"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-4xl font-black uppercase mb-6 text-destructive">
          DELETE CHATBOT
        </h2>

        <div className="separator-thick mb-6"></div>

        <p className="text-lg font-bold mb-4">
          You are about to permanently delete:
        </p>

        <div className="border-2 border-foreground p-4 mb-6 bg-secondary">
          <p className="text-2xl font-black">{chatbot.name}</p>
        </div>

        <p className="text-base font-mono mb-6">
          This action cannot be undone. All associated chat history will be
          deleted.
        </p>

        <p className="text-sm font-bold uppercase tracking-wider mb-4">
          Type the chatbot name to confirm:
        </p>

        <input
          type="text"
          value={confirmText}
          onChange={(e) => setConfirmText(e.target.value)}
          placeholder={chatbot.name}
          className="input-brutalist mb-8"
          disabled={isLoading}
        />

        <div className="separator-thick mb-6"></div>

        <div className="flex gap-4">
          <button
            onClick={onCancel}
            className="flex-1 btn-brutalist"
            disabled={isLoading}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={!isConfirmed || isLoading}
            className="flex-1 btn-brutalist border-destructive text-destructive disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? "Deleting..." : "Delete"}
          </button>
        </div>
      </div>
    </div>
  );
}
