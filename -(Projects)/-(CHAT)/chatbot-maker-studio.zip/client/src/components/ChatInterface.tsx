import { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface ChatInterfaceProps {
  chatbotId: number;
  onClose: () => void;
}

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function ChatInterface({
  chatbotId,
  onClose,
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatbotQuery = trpc.chatbots.getById.useQuery({ id: chatbotId });
  const historyQuery = trpc.chatbots.getChatHistory.useQuery({ chatbotId });
  const sendMessageMutation = trpc.chatbots.sendMessage.useMutation({
    onSuccess: (response) => {
      setMessages((prev) => [
        ...prev,
        { role: "user", content: response.userMessage },
        { role: "assistant", content: response.assistantMessage },
      ]);
      setInput("");
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
    },
  });

  const clearHistoryMutation = trpc.chatbots.clearChatHistory.useMutation({
    onSuccess: () => {
      setMessages([]);
      toast.success("Chat history cleared");
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
    },
  });

  // Load chat history on mount
  useEffect(() => {
    if (historyQuery.data) {
      setMessages(
        historyQuery.data.map((msg) => ({
          role: msg.role,
          content: msg.content,
        }))
      );
    }
  }, [historyQuery.data]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();

    if (!input.trim()) return;

    sendMessageMutation.mutate({
      chatbotId,
      userMessage: input.trim(),
    });
  };

  return (
    <div className="dialog-overlay-brutalist" onClick={onClose}>
      <div
        className="dialog-content-brutalist max-w-2xl h-96 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="mb-4 pb-4 border-b-2 border-foreground">
          <h2 className="text-3xl font-black uppercase">
            {chatbotQuery.data?.name || "Chat"}
          </h2>
          <p className="text-xs font-mono text-muted-foreground mt-1">
            Test the chatbot in real-time
          </p>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto mb-4 space-y-3 border-2 border-foreground p-4 bg-secondary">
          {messages.length === 0 ? (
            <div className="text-center text-muted-foreground font-mono text-sm">
              <p>No messages yet. Start typing to begin.</p>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-xs px-3 py-2 border border-foreground ${
                    msg.role === "user"
                      ? "bg-foreground text-background"
                      : "bg-background text-foreground"
                  }`}
                >
                  <p className="text-sm font-mono break-words">
                    {msg.content}
                  </p>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <form onSubmit={handleSendMessage} className="space-y-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="input-brutalist"
            disabled={sendMessageMutation.isPending}
            autoFocus
          />

          <div className="flex gap-2">
            <button
              type="submit"
              disabled={sendMessageMutation.isPending || !input.trim()}
              className="flex-1 btn-brutalist-primary text-sm py-2"
            >
              {sendMessageMutation.isPending ? "Sending..." : "Send"}
            </button>
            <button
              type="button"
              onClick={() => clearHistoryMutation.mutate({ chatbotId })}
              disabled={clearHistoryMutation.isPending}
              className="btn-brutalist text-sm py-2 px-4"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={onClose}
              className="btn-brutalist text-sm py-2 px-4"
            >
              Close
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
