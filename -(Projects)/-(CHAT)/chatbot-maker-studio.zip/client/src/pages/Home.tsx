import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import ChatbotDashboard from "@/components/ChatbotDashboard";
import CreateChatbotForm from "@/components/CreateChatbotForm";
import ChatInterface from "@/components/ChatInterface";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedChatbotId, setSelectedChatbotId] = useState<number | null>(null);
  const [showChatInterface, setShowChatInterface] = useState(false);

  const chatbotsQuery = trpc.chatbots.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-4">
        <div className="max-w-2xl text-center">
          <h1 className="text-brutalist-xl mb-8">
            <span className="bracket-left">CHATBOT</span>
            <br />
            <span className="bracket-right">MAKER STUDIO</span>
          </h1>
          <p className="text-2xl font-bold mb-12 uppercase tracking-wider">
            Design. Configure. Deploy.
          </p>
          <button
            onClick={startLogin}
            className="btn-brutalist-primary text-2xl px-12 py-6"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const handleCreateBot = () => {
    setShowCreateForm(true);
  };

  const handleFormClose = () => {
    setShowCreateForm(false);
    chatbotsQuery.refetch();
  };

  const handleTestChat = (botId: number) => {
    setSelectedChatbotId(botId);
    setShowChatInterface(true);
  };

  const handleCloseChatInterface = () => {
    setShowChatInterface(false);
    setSelectedChatbotId(null);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b-4 border-foreground py-8 px-4 sm:px-8">
        <div className="container">
          <div className="flex items-center justify-between">
            <h1 className="text-5xl font-black uppercase tracking-tighter">
              <span className="bracket-left">STUDIO</span>
            </h1>
            <div className="text-right">
              <p className="text-sm font-bold uppercase tracking-wider">
                Logged in as {user?.name || user?.email}
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-16 px-4 sm:px-8">
        {/* Create Button Section */}
        <div className="mb-16 flex items-center justify-between">
          <div>
            <h2 className="text-4xl font-black uppercase tracking-tight mb-2">
              Your Chatbots
            </h2>
            <div className="h-1 w-32 bg-foreground"></div>
          </div>
          <button
            onClick={handleCreateBot}
            className="btn-brutalist-primary text-lg px-8 py-4"
          >
            + Create New
          </button>
        </div>

        {/* Dashboard or Empty State */}
        {chatbotsQuery.isLoading ? (
          <div className="text-center py-16">
            <p className="text-2xl font-bold">LOADING...</p>
          </div>
        ) : chatbotsQuery.data && chatbotsQuery.data.length > 0 ? (
          <ChatbotDashboard
            chatbots={chatbotsQuery.data}
            onTestChat={handleTestChat}
            onRefresh={() => chatbotsQuery.refetch()}
          />
        ) : (
          <div className="border-4 border-foreground p-16 text-center">
            <p className="text-3xl font-black uppercase mb-4">
              NO CHATBOTS YET
            </p>
            <p className="text-lg mb-8 font-bold">
              Create your first chatbot to get started
            </p>
            <button
              onClick={handleCreateBot}
              className="btn-brutalist text-lg px-8 py-4"
            >
              Create Chatbot
            </button>
          </div>
        )}
      </main>

      {/* Create Form Modal */}
      {showCreateForm && (
        <CreateChatbotForm onClose={handleFormClose} />
      )}

      {/* Chat Interface Modal */}
      {showChatInterface && selectedChatbotId && (
        <ChatInterface
          chatbotId={selectedChatbotId}
          onClose={handleCloseChatInterface}
        />
      )}
    </div>
  );
}
