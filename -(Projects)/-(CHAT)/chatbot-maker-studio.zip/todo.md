# Chatbot Maker Studio - TODO

## Database & Backend
- [ ] Create chatbots table with id, name, description, avatar/emoji, systemPrompt, createdAt, updatedAt
- [ ] Create chat_messages table for storing conversation history (botId, role, content, createdAt)
- [ ] Write database query helpers in server/db.ts
- [ ] Create tRPC procedures: createChatbot, getChatbots, getChatbotById, updateChatbot, deleteChatbot
- [ ] Create tRPC procedure: sendChatMessage (for live chat testing)
- [ ] Create tRPC procedure: downloadPythonScript (returns pre-configured Python runner)
- [ ] Write vitest tests for all procedures

## Frontend UI - Brutalist Design System
- [ ] Create global brutalist CSS with heavy sans-serif typography, stark black/white, high contrast
- [ ] Create BrutalistButton component (thick borders, no rounded corners)
- [ ] Create BrutalistCard component (stark borders, no shadows)
- [ ] Create BrutalistHeading component (oversized, heavy-weight typography)
- [ ] Create BrutalistInput component (minimal styling, stark borders)
- [ ] Create BrutalistTextarea component (minimal styling, stark borders)

## Dashboard Page
- [ ] Build dashboard layout displaying all chatbots
- [ ] Show each chatbot with name, description, avatar/emoji
- [ ] Add action buttons: Edit, Test Chat, Delete, Download Python Script
- [ ] Add "Create New Chatbot" button
- [ ] Implement empty state when no chatbots exist

## Create/Edit Chatbot Form
- [ ] Build form with fields: name, avatar/emoji, description, systemPrompt
- [ ] Implement form validation (name required, systemPrompt required)
- [ ] Add submit and cancel buttons
- [ ] Implement edit mode (pre-fill form with existing chatbot data)
- [ ] Show success/error toast after save

## Live Chat Interface
- [ ] Build chat modal/drawer that opens from dashboard
- [ ] Display conversation history (bot messages and user messages)
- [ ] Implement message input with send button
- [ ] Integrate with sendChatMessage procedure to get bot responses
- [ ] Show loading state while waiting for bot response
- [ ] Clear chat history when switching between bots

## Delete Chatbot
- [ ] Implement confirmation dialog with explicit warning
- [ ] Require deliberate user action (e.g., type bot name to confirm)
- [ ] Call deleteChatbot procedure on confirmation
- [ ] Show success toast and refresh dashboard

## Python Script Download
- [ ] Generate pre-configured Python script with bot name and system prompt
- [ ] Include LLM API integration (use OpenAI or similar)
- [ ] Create downloadable .py file
- [ ] Implement download trigger from dashboard action button

## Local Python Runner Script
- [ ] Create standalone Python script template for local execution
- [ ] Include CLI interface for running the bot
- [ ] Support conversation history and multi-turn interactions
- [ ] Document setup and usage instructions

## Testing & Deployment
- [ ] Test all CRUD operations on dashboard
- [ ] Test create/edit form validation
- [ ] Test live chat with multiple messages
- [ ] Test delete confirmation flow
- [ ] Test Python script download and execution
- [ ] Verify brutalist design consistency across all pages
- [ ] Create checkpoint before delivery
