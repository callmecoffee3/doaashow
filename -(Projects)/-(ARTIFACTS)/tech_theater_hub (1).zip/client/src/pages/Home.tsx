import { useState, useMemo } from 'react';
import { Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BudgetChallenge } from '@/components/BudgetChallenge';
import { Footer } from '@/components/Footer';
import { projects, categories, difficulties } from '@/lib/projects';
import type { Project } from '@/lib/projects';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | null>(null);

  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      const matchesSearch =
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.tools.some((tool) =>
          tool.toLowerCase().includes(searchQuery.toLowerCase())
        );

      const matchesCategory = !selectedCategory || project.category === selectedCategory;
      const matchesDifficulty = !selectedDifficulty || project.difficulty === selectedDifficulty;

      return matchesSearch && matchesCategory && matchesDifficulty;
    });
  }, [searchQuery, selectedCategory, selectedDifficulty]);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section
        className="relative w-full py-24 px-4 text-center overflow-hidden"
        style={{
          backgroundImage: 'url(/manus-storage/hero_background_2fdae15b.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-black/60" />
        <div className="relative z-10 max-w-4xl mx-auto animate-in fade-in slide-in-from-top-8 duration-700">
          <div className="flex justify-center mb-8 animate-in fade-in slide-in-from-top-12 duration-700 delay-100">
            <img
              src="/manus-storage/logo_58064a27.png"
              alt="Tech Theater Hub Logo"
              className="h-20 w-20 drop-shadow-lg"
            />
          </div>
          <h1 className="font-display-bold text-5xl md:text-7xl text-white mb-6 drop-shadow-lg animate-in fade-in slide-in-from-top-12 duration-700 delay-200">
            Tech Theater Hub
          </h1>
          <p className="text-xl md:text-2xl text-white/95 mb-4 drop-shadow-md animate-in fade-in slide-in-from-top-12 duration-700 delay-300">
            Discover innovative, budget-friendly tech-theater projects under $20
          </p>
          <p className="text-lg text-white/80 drop-shadow-md animate-in fade-in slide-in-from-top-12 duration-700 delay-400">
            Searchable resource for performers, makers, and tech enthusiasts
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Search Bar */}
        <div className="mb-12 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-500">
          <div className="relative group">
            <Search className="absolute left-4 top-3.5 h-5 w-5 text-accent transition-colors group-focus-within:text-accent" />
            <Input
              placeholder="Search projects, tools, or ideas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 py-6 text-lg border-2 border-border focus:border-accent focus:ring-accent/20 transition-all"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="mb-10 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-600">
          {/* Category Filter */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Filter className="h-5 w-5 text-accent" />
              <h3 className="font-display text-lg text-foreground">Category</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedCategory === null ? 'default' : 'outline'}
                onClick={() => setSelectedCategory(null)}
                className="rounded-full font-medium transition-all hover:shadow-md"
              >
                All Categories
              </Button>
              {categories.map((cat) => (
                <Button
                  key={cat.id}
                  variant={selectedCategory === cat.id ? 'default' : 'outline'}
                  onClick={() => setSelectedCategory(cat.id)}
                  className="rounded-full font-medium transition-all hover:shadow-md"
                >
                  {cat.icon} {cat.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Difficulty Filter */}
          <div>
            <h3 className="font-display text-lg text-foreground mb-4">Difficulty</h3>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedDifficulty === null ? 'default' : 'outline'}
                onClick={() => setSelectedDifficulty(null)}
                className="rounded-full font-medium transition-all hover:shadow-md"
              >
                All Levels
              </Button>
              {difficulties.map((diff) => (
                <Button
                  key={diff.id}
                  variant={selectedDifficulty === diff.id ? 'default' : 'outline'}
                  onClick={() => setSelectedDifficulty(diff.id)}
                  className="rounded-full font-medium transition-all hover:shadow-md"
                >
                  {diff.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-8 animate-in fade-in duration-500 delay-700">
          <p className="text-muted-foreground text-sm">
            Showing <span className="font-semibold text-accent text-base">{filteredProjects.length}</span> of{' '}
            <span className="font-semibold text-foreground text-base">{projects.length}</span> projects
          </p>
        </div>

        {/* Projects Grid */}
        {filteredProjects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project, index) => (
              <ProjectCard key={project.id} project={project} index={index} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 animate-in fade-in duration-300">
            <p className="text-lg text-muted-foreground mb-6">
              No projects found matching your search.
            </p>
            <Button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory(null);
                setSelectedDifficulty(null);
              }}
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-medium"
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Budget Challenge Section */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <BudgetChallenge />
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
}

function ProjectCard({ project, index }: { project: Project; index: number }) {
  const categoryInfo = categories.find((c) => c.id === project.category);
  const difficultyInfo = difficulties.find((d) => d.id === project.difficulty);

  return (
    <div
      className="group relative bg-card rounded-xl border border-border p-6 hover:shadow-xl transition-all duration-300 hover:border-accent/60 hover:-translate-y-1 animate-in fade-in slide-in-from-bottom-4"
      style={{
        animationDelay: `${index * 40}ms`,
        animationFillMode: 'both'
      }}
    >
      {/* Spotlight effect on hover */}
      <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at 50% 0%, rgba(251, 191, 36, 0.15) 0%, transparent 70%)'
        }}
      />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="font-display text-xl text-foreground mb-1 group-hover:text-accent transition-colors duration-200">
              {project.title}
            </h3>
          </div>
          <span className="text-3xl ml-3 group-hover:scale-110 transition-transform duration-200">{categoryInfo?.icon}</span>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-4 line-clamp-3 leading-relaxed">
          {project.description}
        </p>

        {/* Badges */}
        <div className="flex flex-wrap gap-2 mb-4">
          <Badge variant="secondary" className="bg-accent/15 text-accent border-accent/30 font-medium">
            {project.budget}
          </Badge>
          {difficultyInfo && (
            <Badge
              variant="secondary"
              className={`${difficultyInfo.color} border-0 font-medium`}
            >
              {difficultyInfo.label}
            </Badge>
          )}
        </div>

        {/* Tools */}
        <div className="mb-4">
          <p className="text-xs font-semibold text-muted-foreground mb-2.5 uppercase tracking-wider">
            Tools
          </p>
          <div className="flex flex-wrap gap-1.5">
            {project.tools.slice(0, 3).map((tool) => (
              <span
                key={tool}
                className="inline-block px-3 py-1.5 text-xs bg-secondary text-secondary-foreground rounded-full font-medium"
              >
                {tool}
              </span>
            ))}
            {project.tools.length > 3 && (
              <span className="inline-block px-3 py-1.5 text-xs bg-secondary text-secondary-foreground rounded-full font-medium">
                +{project.tools.length - 3}
              </span>
            )}
          </div>
        </div>

        {/* Ideas Preview */}
        <div className="mb-5">
          <p className="text-xs font-semibold text-muted-foreground mb-2.5 uppercase tracking-wider">
            Project Ideas
          </p>
          <ul className="text-sm text-foreground space-y-1.5">
            {project.ideas.slice(0, 2).map((idea, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-accent mt-1 flex-shrink-0">▸</span>
                <span className="leading-snug">{idea}</span>
              </li>
            ))}
            {project.ideas.length > 2 && (
              <li className="text-accent text-xs font-semibold pt-1">
                +{project.ideas.length - 2} more ideas
              </li>
            )}
          </ul>
        </div>

        {/* Learn More Button */}
        <Button
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold group-hover:shadow-lg transition-all duration-200 active:scale-95"
        >
          Explore Project
        </Button>
      </div>
    </div>
  );
}
