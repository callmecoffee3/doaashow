import { budgetChallenge } from '@/lib/projects';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap } from 'lucide-react';

export function BudgetChallenge() {
  return (
    <section className="py-16 px-4 bg-gradient-to-br from-accent/5 to-accent/10 rounded-2xl mb-12 border border-accent/20">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Zap className="h-6 w-6 text-accent" />
            <h2 className="font-display-bold text-4xl text-foreground">
              {budgetChallenge.title}
            </h2>
            <Zap className="h-6 w-6 text-accent" />
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {budgetChallenge.description}
          </p>
        </div>

        {/* Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
          {budgetChallenge.highlights.map((highlight, idx) => (
            <div key={idx} className="flex items-start gap-3 p-4 bg-background rounded-lg border border-border">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center mt-0.5">
                <span className="text-accent font-bold text-sm">✓</span>
              </div>
              <p className="text-foreground font-medium">{highlight}</p>
            </div>
          ))}
        </div>

        {/* Example Builds */}
        <div>
          <h3 className="font-display text-2xl text-foreground mb-6 text-center">
            Example $20 Builds
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {budgetChallenge.exampleBuilds.map((build, idx) => (
              <Card key={idx} className="p-6 border-2 border-border hover:border-accent/50 transition-colors">
                <div className="mb-3">
                  <Badge className="bg-accent/20 text-accent border-accent/30 mb-3">
                    {build.totalBudget}
                  </Badge>
                  <h4 className="font-display text-lg text-foreground mb-2">
                    {build.name}
                  </h4>
                </div>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                  {build.description}
                </p>
                <div className="pt-4 border-t border-border">
                  <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">
                    Projects Included
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {build.projects.map((proj) => (
                      <span key={proj} className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded-full">
                        {proj.replace(/-/g, ' ')}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
