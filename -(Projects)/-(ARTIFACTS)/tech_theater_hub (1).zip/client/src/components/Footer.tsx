import { creator } from '@/lib/projects';

export function Footer() {
  return (
    <footer className="bg-card border-t border-border py-8 px-4 mt-16">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="font-display text-lg text-foreground mb-3">
              Tech Theater Hub
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              A searchable resource for affordable, innovative tech-theater projects that empower performers and creators to integrate technology into their craft without breaking the bank.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-foreground mb-3">Categories</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-accent transition-colors">AI & Scripting</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Hardware & Electronics</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Software & Control</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Mobile Apps</a></li>
            </ul>
          </div>

          {/* Creator */}
          <div>
            <h3 className="font-semibold text-foreground mb-3">Created By</h3>
            <div className="bg-gradient-to-br from-accent/10 to-accent/5 rounded-lg p-4 border-2 border-accent/30 hover:border-accent/60 transition-colors">
              <p className="text-sm font-semibold text-foreground mb-2">
                {creator.name}
              </p>
              <p className="text-xs text-accent font-mono font-bold mb-2">
                @{creator.username}
              </p>
              <p className="text-xs text-muted-foreground">
                {creator.role}
              </p>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border pt-6 text-center">
          <p className="text-xs text-muted-foreground mb-2">
            © 2026 Tech Theater Hub. All projects are designed to be budget-friendly and accessible to everyone.
          </p>
          <p className="text-xs text-accent font-semibold mb-2">
            Created by <span className="font-bold">Matt Grosso</span> (@callmecoffee3)
          </p>
          <p className="text-xs text-muted-foreground">
            Created with <span className="text-accent">♪</span> for performers, makers, and tech enthusiasts
          </p>
        </div>
      </div>
    </footer>
  );
}
