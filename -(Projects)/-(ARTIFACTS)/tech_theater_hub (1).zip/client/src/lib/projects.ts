export interface Project {
  id: string;
  title: string;
  description: string;
  category: 'ai' | 'hardware' | 'software' | 'apps';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  budget: string;
  tools: string[];
  ideas: string[];
  resources?: string[];
}

export const projects: Project[] = [
  {
    id: 'ai-scene-prompts',
    title: 'AI-Generated Scene Prompts',
    description: 'Use free AI chat models to generate unique scene prompts, dialogue snippets, or character backstories to inspire improvisation or script development.',
    category: 'ai',
    difficulty: 'beginner',
    budget: 'Free',
    tools: ['ChatGPT', 'Claude', 'Meta.ai'],
    ideas: [
      'Generate unique scene prompts for improv exercises',
      'Create character backstories and motivations',
      'Brainstorm dialogue variations for practice',
      'Develop thematic elements for productions'
    ]
  },
  {
    id: 'ai-character-dialogue',
    title: 'Character Dialogue Exploration',
    description: 'Input character descriptions and ask AI to generate dialogue in their voice, helping actors understand their roles better and practice different interpretations.',
    category: 'ai',
    difficulty: 'beginner',
    budget: 'Free',
    tools: ['ChatGPT', 'Claude', 'Storyflow'],
    ideas: [
      'Generate dialogue in specific character voices',
      'Explore different emotional interpretations',
      'Practice accent and speech patterns',
      'Develop character consistency'
    ]
  },
  {
    id: 'ai-script-brainstorm',
    title: 'Script Brainstorming with AI',
    description: 'Utilize AI to brainstorm plot twists, alternative endings, or thematic elements for a play. Perfect for collaborative writing and creative exploration.',
    category: 'ai',
    difficulty: 'intermediate',
    budget: 'Free',
    tools: ['Storyflow', 'Sudowrite', 'Claude'],
    ideas: [
      'Develop plot structures and story arcs',
      'Brainstorm alternative endings',
      'Explore thematic variations',
      'Create season bibles for series'
    ]
  },
  {
    id: 'esp32-led-lighting',
    title: 'ESP32-Controlled LED Lighting',
    description: 'Use an ESP32 microcontroller (around $8-$10) with LED strips to create dynamic lighting effects that can be pre-programmed or triggered during a performance.',
    category: 'hardware',
    difficulty: 'intermediate',
    budget: '$15-20',
    tools: ['ESP32', 'LED Strips', 'WLED', 'Arduino IDE'],
    ideas: [
      'Create mood-based lighting sequences',
      'Simulate time changes (sunrise, sunset)',
      'Build interactive prop lighting',
      'Trigger lights via wireless remote'
    ],
    resources: [
      'https://install.wled.me/',
      'https://www.instructables.com/Motion-Tracking-Michael-Meyers/'
    ]
  },
  {
    id: 'sound-activated-props',
    title: 'Sound-Activated Props',
    description: 'Integrate a cheap sound sensor with an ESP32 to make props react to sound cues, such as a prop glowing when a specific word is spoken.',
    category: 'hardware',
    difficulty: 'intermediate',
    budget: '$12-18',
    tools: ['ESP32', 'Sound Sensor', 'LED', 'Arduino IDE'],
    ideas: [
      'Props that glow on cue words',
      'Interactive stage elements',
      'Sound-reactive lighting effects',
      'Audience-responsive installations'
    ]
  },
  {
    id: 'diy-motion-tracking',
    title: 'DIY Motion Tracking System',
    description: 'Explore DIY head tracking systems using webcams and open-source software, potentially under $20, to control visual elements or soundscapes based on an actor\'s movement.',
    category: 'hardware',
    difficulty: 'advanced',
    budget: '$15-20',
    tools: ['Webcam', 'OpenCV', 'Python', 'Head Tracker Software'],
    ideas: [
      'Track actor movement for lighting control',
      'Control sound effects via motion',
      'Create interactive stage projections',
      'Build gesture-based cue systems'
    ],
    resources: [
      'https://www.youtube.com/watch?v=5Nimz4M-sxU',
      'https://github.com/dlktdr/HeadTracker'
    ]
  },
  {
    id: 'sound-cueing-software',
    title: 'Software-Based Sound Cueing',
    description: 'Utilize free sound cueing software to manage and play back audio cues during a show. These can be triggered manually or potentially integrated with simple physical triggers.',
    category: 'software',
    difficulty: 'beginner',
    budget: 'Free',
    tools: ['MultiPlay', 'SoundShow', 'QLab (basic)'],
    ideas: [
      'Organize and trigger sound effects',
      'Manage music cues for scenes',
      'Create automated sound sequences',
      'Integrate with lighting cues'
    ]
  },
  {
    id: 'voice-activated-cues',
    title: 'Voice-Activated Cues (DIY)',
    description: 'With an ESP32 and a microphone module, experiment with basic voice recognition to trigger lights or sounds during performance.',
    category: 'software',
    difficulty: 'advanced',
    budget: '$18-20',
    tools: ['ESP32', 'Microphone Module', 'Voice Recognition Library'],
    ideas: [
      'Trigger cues with specific words',
      'Build hands-free stage control',
      'Create interactive dialogue responses',
      'Automate complex cue sequences'
    ]
  },
  {
    id: 'smartphone-controller',
    title: 'Smartphone as Stage Controller',
    description: 'Use a smartphone with a simple web interface hosted on an ESP32 to remotely control stage elements like lights, sound, and props.',
    category: 'software',
    difficulty: 'intermediate',
    budget: '$10-15',
    tools: ['ESP32', 'Web Interface', 'WiFi'],
    ideas: [
      'Remote control stage lighting',
      'Trigger sound effects from phone',
      'Manage multiple cues simultaneously',
      'Create custom control layouts'
    ]
  },
  {
    id: 'line-memorization-apps',
    title: 'Line Memorization Apps',
    description: 'Use dedicated apps to learn lines efficiently, often featuring progressive hiding, cue reading, and playback options for solo rehearsal.',
    category: 'apps',
    difficulty: 'beginner',
    budget: '$0-10',
    tools: ['LineLearner', 'ScriptRehearser', 'Run Lines With Me', 'ActOnCue'],
    ideas: [
      'Progressive text hiding for memorization',
      'Cue reading with AI voices',
      'Self-tape recording features',
      'Cross-platform rehearsal sync'
    ]
  },
  {
    id: 'virtual-rehearsal-spaces',
    title: 'Virtual Rehearsal Spaces',
    description: 'Use apps and tools that offer basic blocking and ground plan management for virtual rehearsals, helping actors familiarize themselves with set layouts.',
    category: 'apps',
    difficulty: 'beginner',
    budget: 'Free-$10',
    tools: ['Stage Write', 'Scriptation', 'CuePad'],
    ideas: [
      'Create digital ground plans',
      'Visualize blocking before rehearsal',
      'Share staging with cast remotely',
      'Annotate scripts with blocking notes'
    ]
  },
  {
    id: 'self-tape-recording',
    title: 'Self-Tape Recording with Teleprompter',
    description: 'Utilize smartphone apps with teleprompter features for self-taping auditions, combining line reading with professional recording capabilities.',
    category: 'apps',
    difficulty: 'beginner',
    budget: 'Free-$5',
    tools: ['Scriptation', 'coldRead', 'Slatable'],
    ideas: [
      'Record audition tapes on smartphone',
      'Use teleprompter for line reading',
      'Multiple takes and edits',
      'Direct submission to casting directors'
    ]
  }
];

export const categories = [
  { id: 'ai', label: 'AI & Scripting', icon: '🧠' },
  { id: 'hardware', label: 'Hardware & Electronics', icon: '⚙️' },
  { id: 'software', label: 'Software & Control', icon: '💻' },
  { id: 'apps', label: 'Mobile Apps', icon: '📱' }
];

export const difficulties = [
  { id: 'beginner', label: 'Beginner', color: 'bg-green-100 text-green-800' },
  { id: 'intermediate', label: 'Intermediate', color: 'bg-amber-100 text-amber-800' },
  { id: 'advanced', label: 'Advanced', color: 'bg-red-100 text-red-800' }
];

export const budgetChallenge = {
  title: 'The $20 Budget Challenge',
  description: 'Can you build a complete tech-theater setup for exactly $20? This challenge showcases how creative makers are pushing the boundaries of affordable theatrical technology.',
  highlights: [
    'Combine multiple projects to create a complete system',
    'Mix free software with budget hardware',
    'Build interactive stage effects on a shoestring budget',
    'Share your setup and inspire the community'
  ],
  exampleBuilds: [
    {
      name: 'Complete LED Lighting + Sound Cue System',
      projects: ['esp32-led-lighting', 'sound-cueing-software'],
      totalBudget: '$15-20',
      description: 'Combine an ESP32-controlled LED system with free sound cueing software for a fully functional stage automation setup.'
    },
    {
      name: 'Interactive Props + Actor Tools',
      projects: ['sound-activated-props', 'line-memorization-apps'],
      totalBudget: '$12-18',
      description: 'Build sound-reactive props while using free line memorization apps to rehearse—a complete performance toolkit.'
    },
    {
      name: 'AI Writing + DIY Motion Control',
      projects: ['ai-script-brainstorm', 'diy-motion-tracking'],
      totalBudget: '$15-20',
      description: 'Develop scripts with AI while building a DIY motion tracking system to control stage elements based on actor movement.'
    }
  ]
};

export const creator = {
  name: 'Matt Grosso',
  username: 'callmecoffee3',
  role: 'Creator & Curator'
};
